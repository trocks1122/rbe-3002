#!/usr/bin/env python

import rospy, tf, numpy, math
from kobuki_msgs.msg import BumperEvent
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped
from tf.transformations import euler_from_quaternion
# Add additional imports for each of the message types used

wheel_rad = 3.5 / 100.0 #cm
wheel_base = 23.0 / 100.0 #cm


#drive to a goal subscribed as /move_base_simple/goal
def navToPose(goal):
    """Drive to a goal subscribed to from /move_base_simple/goal"""
    #compute angle required to make straight-line move to desired pose
    global xPosition
    global yPosition
    global theta
    #capture desired x and y positions
    desiredY = goal.pose.position.y - yPosition
    desiredX = goal.pose.position.x - xPosition
    #capture desired angle
    quat = goal.pose.orientation
    q = [quat.x, quat.y, quat.z, quat.w]
    roll, pitch, yaw = euler_from_quaternion(q)
    desiredT = math.atan(desiredY/desiredX)
    if (theta > 180):
        desiredT += (theta-180)
    else:
        desiredT = (-1*desiredT)
    print desiredT
    #compute distance to target
    distance = math.sqrt((desiredX*desiredX)+(desiredY*desiredY))
    #compute initial turn amount
    initialTurn = math.degrees(desiredT)+theta
    print "spin!" #turn to calculated angle
    rotate(initialTurn)
    print "move!" #move in straight line specified distance to new pose
    driveStraight(0.25, distance)
    rospy.sleep(2)
    print "spin!" #spin to final angle 
    rotate(goal.pose.orientation.w)
    print "done"


#This function sequentially calls methods to perform a trajectory.
def executeTrajectory():
    #run on bumper press 
    print 'about to drive'
    driveStraight(.2,.6)#drive forward 60cm
    print 'just drove'
    rotate(-90) #turn right 90 degrees
    driveStraight(.2,.45) #drive forward 45cm
    rotate(135)#turn left 135 degrees


def publishTwist(lin_Vel, ang_Vel):
    """Send a movement (twist) message."""
    print 'what a twist' #moves the robot at the given velocities
    global pub
    msg = Twist()
    msg.linear.x = lin_Vel
    msg.angular.z = ang_Vel
    pub.publish(msg)

#This function accepts two wheel velocities and a time interval.
def spinWheels(u1, u2, time):
    """This function accepts two wheel velocities and a time interval."""
    global pub

    r = wheel_rad*math.pi #wheel circumfrence 
    b = wheel_base*math.pi #wheel base circumfrence

    #compute wheel speeds
    u = (((u1*r)+(u2*r))/2)    #Determines the linear velocity of base based on the wheel
    w = (abs((u1*r)-(u2*r))*b)    #Determines the angular velocity of base on the wheels.
    start = rospy.Time().now().secs
    #create movement and stop messages
    move_msg = Twist() #creates a move_msg object inheriting type from the Twist() class
    move_msg.linear.x = u #sets linear velocity
    move_msg.angular.z = w #sets angular velocity (Populates messages with data.)
    #message to stop the robot
    stop_msg = Twist()
    stop_msg.linear.x = 0
    stop_msg.angular.z = 0
    #publish move message for desired time
    while(rospy.Time().now().secs - start < time and not rospy.is_shutdown()): # waits for said time and checks for ctrl C
        pub.publish(move_msg) #publishes the move_msg
    pub.publish(stop_msg)

def xyPos(xCoor, yCoor): #returns the polar location of xy coords
    location = math.sqrt((xCoor*xCoor)+(yCoor*yCoor))
    return location

#This function accepts a speed and a distance for the robot to move in a straight line
def driveStraight(speed, distance):
  # """This function accepts a speed and a distance for the robot to move in a straight line"""
  initialX = xPosition
  initialY = yPosition
  initialPos = xyPos(initialX, initialY)# finds the starting location
  atTarget = False
    #Loop until the distance between the attached frame and the origin is equal to the
    #distance specified 
  while (not atTarget and not rospy.is_shutdown()): #runs until at the location, or the script is shutdown
        currentX = xPosition
        currentY = yPosition
        currentDistance = abs(xyPos(currentX, currentY)-initialPos) #finds the distance to the desired point
        print currentDistance
        if (currentDistance >= distance):
            atTarget = True
            publishTwist(0, 0)
            print atTarget
        else:
            publishTwist(speed, 0)
            rospy.sleep(0.15)
            

def stopTurtle():
    publishTwist(0,0)
    
def driveSmooth(speed, distance):
    for i in range(1, 11, 1):
        print i/10
        driveStraight(i, .1) #smooth acceleration
    

#Accepts an angle and makes the robot rotate around it.
def rotate(angle):
    global odom_list
    global pose
    initialAngle = theta
    if (angle > 180 or angle<-180):
        print "angle is to large or small"
    vel = Twist()
    done = True
    # set rotation direction
    toTurn = angle+theta
    error = toTurn-theta
    if(angle > 0):
	   #left rotate
        vel.angular.z = .2
    elif(angle < 0):
	#right rotate
	   vel.angular.z = -.2 
    while ((abs(error) >= 2) and not rospy.is_shutdown()):
        pub.publish(vel)  

    vel.angular.z = 0.0
    pub.publish(vel)


#keeps track of current location and orientation
def tCallback(event):
    
    global pose
    global xPosition
    global yPosition
    global theta

    odom_list.waitForTransform('map', 'base_footprint', rospy.Time(0), rospy.Duration(1.0))
    (position, orientation) = odom_list.lookupTransform('map','base_footprint', rospy.Time(0))
    # the previous 2 lines and next 2 lines are repedative. Joes bad
    xPosition=position[0]
    yPosition=position[1]

    odomW = orientation
    q = [odomW[0], odomW[1], odomW[2], odomW[3]]
    roll, pitch, yaw = euler_from_quaternion(q)
    #convert yaw to degrees
    theta = math.degrees(yaw)



def readBumper(msg):
    """Bumper event callback"""
    if (msg.state == 1):
        # What should happen when the bumper is pressed?
        #Stop forward motion if bumper is pressed
        
        print "Bumper pressed!"
        executeTrajectory()






# This is the program's main function
if __name__ == '__main__':
    rospy.init_node('Trevors_Lab_2_example')
    global pub
    global pose
    global odom_list
    #global odom_tf
    pose = Pose()
    pub = rospy.Publisher('/cmd_vel_mux/input/teleop', Twist, None, queue_size=10) # Publisher for commanding robot motion
    bumper_sub = rospy.Subscriber('/mobile_base/events/bumper', BumperEvent, readBumper, queue_size=1) # Callback function to handle bumper events
    goal_sub = rospy.Subscriber('/lab2goal', PoseStamped, navToPose, queue_size=1)

    rospy.Timer(rospy.Duration(.01), tCallback) # timer callback for robot location
    
    odom_list = tf.TransformListener() #listener for robot location

    rospy.sleep(2)
    print "Starting Lab 2"
    #spinWheels(.2,.2,4)
    #driveStraight(.5, 1)
    #rotate(135)
    #executeTrajectory()
    driveSmooth(1,1)


    while not rospy.is_shutdown():
        rospy.spin()
        #executeTrajectory()
    print "ool, it works, we out"

